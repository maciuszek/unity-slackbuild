using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:AssemblyVersion("2.0.0.0")]
[assembly:AssemblyDelaySign(false)]
[assembly:AssemblyKeyFile("mono.snk")]
