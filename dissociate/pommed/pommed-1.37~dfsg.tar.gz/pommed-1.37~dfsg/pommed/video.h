/*
 * pommed - video.h
 */

#ifndef __VIDEO_H__
#define __VIDEO_H__


void
video_switch(void);

int
video_vt_active(int vt);


#endif /* !__VIDEO_H__ */

