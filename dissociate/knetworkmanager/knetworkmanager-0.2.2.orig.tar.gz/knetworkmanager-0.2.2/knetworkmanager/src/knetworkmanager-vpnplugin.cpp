/***************************************************************************
 *
 * knetworkmanager-vpnplugin.cpp - A NetworkManager frontend for KDE 
 *
 * Copyright (C) 2006 Novell, Inc.
 *
 * Author: Helmut Schaa <hschaa@suse.de>, <helmut.schaa@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **************************************************************************/

#include <qwidget.h>

#include "knetworkmanager-vpnplugin.h"

/***********************
*	class VPNConfigWidget
***********************/

VPNConfigWidget::~VPNConfigWidget()
{

}

VPNConfigWidget::VPNConfigWidget(QWidget* parent, const char* name)
	: QWidget(parent, name)
{

}

void VPNConfigWidget::setVPNData(const QStringList& /*routes*/, const QStringList& /*properties*/)
{

}

QStringList VPNConfigWidget::getVPNProperties()
{
	return QStringList();
}

QStringList VPNConfigWidget::getVPNRoutes()
{
	return QStringList();
}

bool VPNConfigWidget::hasChanged()
{
	return true;
}

bool VPNConfigWidget::isValid(QStringList& /*err_msg*/)
{
	return true;
}

/******************************
*	class VPNAuthentiactionWidget
******************************/

VPNAuthenticationWidget::VPNAuthenticationWidget(QWidget* parent, const char* name)
	: QWidget(parent, name)
{

}

VPNAuthenticationWidget::~VPNAuthenticationWidget()
{

}


QStringList VPNAuthenticationWidget::getPasswords()
{
  return QStringList();
}

void VPNAuthenticationWidget::setVPNData(const QStringList& /*routes*/, const QStringList& /*properties*/)
{

}

bool VPNAuthenticationWidget::needsUserInteraction()
{
	return true;
}

/****************
*	class VPNPlugin
****************/
VPNPlugin::VPNPlugin(QObject* parent, const char* name, const QStringList& args)
	: Plugin(parent, name, args)
{

}

VPNPlugin::~VPNPlugin()
{

}

VPNConfigWidget* VPNPlugin::CreateConfigWidget(QWidget*)
{
	return NULL;
}

VPNAuthenticationWidget* VPNPlugin::CreateAuthenticationWidget(QWidget*)
{
	return NULL;
}

#include "knetworkmanager-vpnplugin.moc"
