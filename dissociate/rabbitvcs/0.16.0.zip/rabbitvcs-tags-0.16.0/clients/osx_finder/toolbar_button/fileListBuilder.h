//
//  fileListBuilder.h
//  CocoPopUp
//
//  Created by mmg on 15/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NSArray* getSelectedFilesList(BOOL* containsFolders, BOOL* containsFiles);
