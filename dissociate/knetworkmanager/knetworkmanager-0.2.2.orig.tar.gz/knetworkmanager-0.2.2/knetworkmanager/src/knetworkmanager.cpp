/***************************************************************************
 *
 * knetworkmanager.cpp - A NetworkManager frontend for KDE 
 *
 * Copyright (C) 2005, 2006 Novell, Inc.
 *
 * Author: Timo Hoenig     <thoenig@suse.de>, <thoenig@nouse.net>
 *         Will Stephenson <wstephenson@suse.de>, <wstephenson@kde.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **************************************************************************/

#include <kdebug.h>

#include "knetworkmanager.h"
#include "knetworkmanager-encryption.h"
#include "knetworkmanager-storage.h"
#include "knetworkmanager-network.h"
#include "settings.h"
#include "klocale.h"

void KNetworkManager::tag ()
{
	KGlobal::config ()->setGroup ("General");
	KGlobal::config ()->writeEntry ("Version", KNETWORKMANAGER_VERSION_STRING);
}

DeviceStore*
KNetworkManager::getDeviceStore ()
{
	return _store;
}

VPN*
KNetworkManager::getVPN ()
{
	return _vpn;
}


NetworkManagerInfo*
KNetworkManager::getNetworkManagerInfo ()
{
	return _nmi;
}

DBusConnection*
KNetworkManager::getDBus ()
{
	return _dbus;
}

Tray*
KNetworkManager::getTray ()
{
	return _tray;
}

State*
KNetworkManager::getState ()
{
	return _state;
}

PluginManager*
KNetworkManager::getPluginManager()
{
	return _pluginManager;
}

KNetworkManager::KNetworkManager () : KUniqueApplication ()
{
	/* Set up D-Bus environment */
	_dbus = new DBusConnection ();
	if (_dbus->push (this) == false)
		QTimer::singleShot (3000, _dbus, SLOT (reconnect ()));

	/* Set up NetworkManagerInfo */
	_nmi = new NetworkManagerInfo ();
	_nmi->push (this);

	/* Set up backend */
	_store = new DeviceStore ( this, "devicestore" );
	_store->push (this);

	/* Set up PluginManager */
	_pluginManager = new PluginManager(this, "pluginmanager");
	
	/* Set up VPN */
	_vpn = new VPN ( this, "vpnobject" );

	/* Set up GUI */
	_tray = new Tray ();
	_tray->push (this);
	_tray->show ();
	setMainWidget (_tray);

	/* Set up state object representing the online/offline state of NM */
	_state = State::getInstance(); //new State();
	_state->push (this);

	/* Check and enable/disable wireless */
	_state->setWirelessState (KNetworkManagerStorage::getInstance ()->getWireless ());

	/* Check and enable/disable online mode */
	_state->setOfflineMode (KNetworkManagerStorage::getInstance ()->getOfflineMode ());

	/* 
	 * Set up signals and slots
	 *
	 */
	
	connect (_nmi, SIGNAL ( networkUpdated( Network *, bool ) ),
		 KNetworkManagerStorage::getInstance(), SLOT( updateNetwork( Network*, bool ) ) );

	connect (_tray, SIGNAL  (userInteraction  (void)),
		 _nmi,  SLOT    (userInteraction (void)));

	connect (_vpn, SIGNAL   (vpnConnectionStateChanged (bool)),
		 _tray, SLOT    (vpnConnectionStateChanged (bool)));

	connect (_tray, SIGNAL  (disconnectVPNConnection (void)),
		 _vpn,  SLOT    (disconnectVPNConnection (void)));

	connect (_tray, SIGNAL  (activateVPNConnection (VPNConnection*)),
		 _vpn,  SLOT    (activateVPNConnection (VPNConnection*)));

	connect (_tray,  SIGNAL (activateDialUp (DialUp*)),
		 _store, SLOT   (activateDialUp (DialUp*)));

	connect (_tray,  SIGNAL (deactivateDialUp (DialUp*)),
		 _store, SLOT   (deactivateDialUp (DialUp*)));

	connect (_tray,  SIGNAL (activateDevice (Device*)),
		 _store, SLOT   (activateDevice (Device*)));

	connect (_tray,  SIGNAL (activateNetwork (Network*, Device*)),
		 _store, SLOT   (activateNetwork (Network*, Device*)));

	connect (_state, SIGNAL (connectionStateChanged ()),
		 _tray,  SLOT   (slotStateChanged ()));

	connect (_store, SIGNAL (deviceStoreChanged (DeviceStore*)),
		 _tray,   SLOT  (slotStateChanged ()));

	connect( _store, SIGNAL( carrierOn( Device * ) ), _tray, SLOT( slotLinkUp( Device * ) ) );
	connect( _store, SIGNAL( carrierOff( Device * ) ), _tray, SLOT( slotLinkDown( Device * ) ) );
	connect( _store, SIGNAL( added( Device * ) ), _tray, SLOT( slotDeviceAdded( Device * ) ) );
	connect( _store, SIGNAL( removed( Device * ) ), _tray, SLOT( slotDeviceRemoved( Device * ) ) );

	connect( _state, SIGNAL( sleeping() ), _tray, SLOT( slotNMSleeping() ) );
	connect( _state, SIGNAL( connecting() ), _tray, SLOT( slotNMConnecting() ) );
	connect( _state, SIGNAL( connected() ), _tray, SLOT( slotNMConnected() ) );
	connect( _state, SIGNAL( disconnected() ), _tray, SLOT( slotNMDisconnected() ) );

	connect( _store, SIGNAL( networkFound( Network * ) ), _tray, SLOT( slotNetworkFound( Network * ) ) );
	connect( _store, SIGNAL( networkDisappeared( Network * ) ), _tray, SLOT( slotNetworkDisappeared( Network * ) ) );
}

KNetworkManager::~KNetworkManager()
{
	/* Tag config file */
	this->tag ();
	
	/* 
	  we need vpn deleted before KApplication
	  because vpn saves the configs in its destructor
	*/
	delete _vpn;

	delete _nmi;
	Settings::writeConfig();
}

#include "knetworkmanager.moc"

