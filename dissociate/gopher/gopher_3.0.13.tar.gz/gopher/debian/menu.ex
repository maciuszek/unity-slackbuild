?package(gopher):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="gopher" command="/usr/bin/gopher"
