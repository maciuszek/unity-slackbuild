/*
 * gpomme - conffile.h
 */

#ifndef __CONFFILE_H__
#define __CONFFILE_H__

int
config_load(void);

int
config_write(void);

int
config_monitor(void);

void
config_gui(void);

#endif /* !__CONFFILE_H__ */
