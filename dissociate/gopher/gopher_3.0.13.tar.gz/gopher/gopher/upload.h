/* upload.h
 * Written by David Allen <s2mdalle@titan.vcu.edu>
 * Simple prototypes for the functions in upload.c
 */

#define UPLOAD_H 1

void BuiltinUploadfile(void);
