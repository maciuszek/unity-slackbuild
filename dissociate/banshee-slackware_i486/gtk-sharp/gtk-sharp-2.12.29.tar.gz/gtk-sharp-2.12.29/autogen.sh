echo
echo "**Error**: autogen.sh has been replaced by bootstrap for the 2.12.x release."
echo "To bootstrap a 2.12.x build run ./bootstrap-2.12."
DIE=1
