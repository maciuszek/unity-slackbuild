/* Headers for virtual method glue compilation */

#include <atk/atk.h>

