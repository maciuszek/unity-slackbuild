/* html2.h
 * Written by David Allen <s2mdalle@titan.vcu.edu>
 * Simple prototypes for html2.c
 */

#define HTML2_H 1

void do_html(GopherObj *ZeGopher);
