/*
 * pommed - cd_eject.h
 */

#ifndef __CD_EJECT_H__
#define __CD_EJECT_H__


void
cd_eject(void);

void
cd_eject_fix_config(void);


#endif /* !__CD_EJECT_H__ */

